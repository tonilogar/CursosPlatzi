const isOdd = require('is-odd');

console.log(isOdd(2));
