function saludar() {
    console.log('Hola mundo!!');
}

module.exports = {
    saludar,
    prop1: 'Hola que tal'
};
