import modulo from './modulo.mjs'

console.log(modulo.prop1);
modulo.saludar();