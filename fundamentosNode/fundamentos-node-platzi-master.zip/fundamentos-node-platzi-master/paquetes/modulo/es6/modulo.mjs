function saludar() {
    console.log('Hola mundo!!');
}

export default {
    saludar,
    prop1: "Soy un modulo experimental",
};