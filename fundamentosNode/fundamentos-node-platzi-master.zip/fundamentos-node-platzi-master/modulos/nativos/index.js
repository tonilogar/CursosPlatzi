const miAddon = require('./build/Release/addon');

console.log(miAddon.hola());