/* console.log('a');
setTimeout(()=>console.log('b'), 0);
console.log('c'); */

setTimeout(()=> console.log('d'), 2000);

for (let i = 0; i < 10000000000; i++){
  
}