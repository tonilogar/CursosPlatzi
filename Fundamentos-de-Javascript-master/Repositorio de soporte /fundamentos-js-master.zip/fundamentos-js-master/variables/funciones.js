var nombre = 'Johan', edad = 28;

// Las funciones sirven para reutilizar código

function imprimirEdad(name, age){
  console.log(`${name} tiene ${age} años`);
}

imprimirEdad(nombre, edad);
imprimirEdad('Juan', 15);
imprimirEdad('Kelly', 21);