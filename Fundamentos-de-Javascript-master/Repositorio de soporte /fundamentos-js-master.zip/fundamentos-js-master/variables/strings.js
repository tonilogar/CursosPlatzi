var nombre = 'Johan', apellido = 'Mosquera';

var nombreEnMayusculas = nombre.toUpperCase();
var apellidoEnMinusculas = apellido.toLocaleLowerCase();

var primeraLetraDelNombre = nombre.charAt(0);

var cantidadDeLetrasDelNombre = nombre.length;

// Concatenar dos String
var nombreCompleto = `${nombre} ${apellido}`;

var str = nombre.charAt(1) + nombre.charAt(2);

var substr = nombre.substr(1, 3);