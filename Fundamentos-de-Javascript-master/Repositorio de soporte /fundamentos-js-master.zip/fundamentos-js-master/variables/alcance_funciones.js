var nombre = 'Johan';

function imprimirNombreMayusculas(nombre){
  nombre = nombre.toUpperCase();
  console.log(nombre);
}

imprimirNombreMayusculas(nombre);