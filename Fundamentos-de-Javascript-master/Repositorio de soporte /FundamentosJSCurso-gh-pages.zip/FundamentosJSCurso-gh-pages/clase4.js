var nombre = 'Sacha', edad = 28

function imprimirEdad(n, e) {
  console.log(`${n} tiene ${e} años`)
}

imprimirEdad(nombre, edad)
imprimirEdad('Vicky', 28)
imprimirEdad('Eric', 24)
imprimirEdad('Darío', 27)
imprimirEdad(25, 'Carlos')
imprimirEdad('Juan')
